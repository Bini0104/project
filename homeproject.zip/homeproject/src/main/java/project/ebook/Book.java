package project.ebook;

public class Book {
    private String title;
    private boolean bookRenal;

    public Book() {
        this.title = title;
    }

    public boolean borrowBook() {
        if (!bookRenal) {
            bookRenal = true;
            return true;
        } else {
            System.out.println("이미 대출된 책입니다.");
            return false;
        }
    }

    public boolean returnBook() {
        if (bookRenal) {
            bookRenal = false;
            return true;
        } else {
            System.out.println("대출되지 않은 책입니다.");
            return false;
        }
    }

    public void title(){};
}