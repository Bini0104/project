package project.ebook;

public class Twilight extends Book {
    @Override
    public void title() {
        System.out.println("Twilight");
    }
}