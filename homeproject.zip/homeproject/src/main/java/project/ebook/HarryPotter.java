package project.ebook;

public class HarryPotter extends Book {
    @Override
    public void title() {
        System.out.println("HarryPotter");
    }
}