package project.ebook;

public class Wonka extends Book {

    @Override
    public void title() {
        System.out.println("Wonka");
    }
}